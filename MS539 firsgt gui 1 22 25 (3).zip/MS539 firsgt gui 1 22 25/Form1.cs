﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_firsgt_gui_1_22_25
{
    public partial class Form1 : Form
    {
        // variables for this form go here
        int num1, die;
        public Form1()
        {
            InitializeComponent();
        }

        private void BTNmake_Click(object sender, EventArgs e)
        {
            MessageBox.Show("uat rocks!");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BTNcheckInt_Click(object sender, EventArgs e)
        {
            // DON'T USE THIS num1 = int.Parse(TBintCheck.Text);

            if (int.TryParse(TBintCheck.Text, out num1))
            {
                MessageBox.Show("Valid int");
            }
            else
            {
                MessageBox.Show("NOT a valid int");
            }
          
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try 
            {
                linkLabel1.LinkVisited = true;
                System.Diagnostics.Process.Start("http://www.uat.edu");
            }
            catch 
            {
                MessageBox.Show("UAT website is not available");
            }
        }

        private void CBDB_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("database skills are needed everywhere");
        }

        private void CBNW_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("SE should know ABOUt networking");
        }

        private void CBGUI_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("I LOVE GUIS");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNRadio_Click(object sender, EventArgs e)
        {
            if (RBFR.Checked)
            {
                MessageBox.Show("good start");
            }
            else if (RBSO.Checked)
            {
                MessageBox.Show("getting there");
            }
            else if (RBJR.Checked)
            {
                MessageBox.Show(" half way there");
            }
            else if (RBSR.Checked)
            {
                MessageBox.Show("home stretch");
            }
            else
            {
                MessageBox.Show("Time to start school");
            }
        }

        private void BTNRoll_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            die = rnd.Next(1,7);
            string path = Directory.GetCurrentDirectory();

            switch(die)
            {
                case 1:
                    {
                        string imagePath = Path.Combine(path, "images", "dice1.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;
                case 2:
                    {
                        string imagePath = Path.Combine(path, "images", "dice2.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;
                 case 3:
                    {
                        string imagePath = Path.Combine(path, "images", "dice3.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;
                case 4:
                    {
                        string imagePath = Path.Combine(path, "images", "dice4.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;
                case 5:
                    {
                        string imagePath = Path.Combine(path, "images", "dice5.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;
                case 6:
                    {
                        string imagePath = Path.Combine(path, "images", "dice6.png");
                        pictureBox1.ImageLocation = imagePath;
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    }
                    break;

            }
                
        }
    }
}
