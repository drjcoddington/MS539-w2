﻿namespace MS539_firsgt_gui_1_22_25
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BTNmake = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TBintCheck = new System.Windows.Forms.TextBox();
            this.BTNcheckInt = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.CBDB = new System.Windows.Forms.CheckBox();
            this.CBNW = new System.Windows.Forms.CheckBox();
            this.CBGUI = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RBBSTrue = new System.Windows.Forms.RadioButton();
            this.RBBSFalse = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RBFR = new System.Windows.Forms.RadioButton();
            this.RBSO = new System.Windows.Forms.RadioButton();
            this.RBJR = new System.Windows.Forms.RadioButton();
            this.RBSR = new System.Windows.Forms.RadioButton();
            this.BTNRadio = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNRoll = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BTNmake
            // 
            this.BTNmake.Location = new System.Drawing.Point(80, 58);
            this.BTNmake.Name = "BTNmake";
            this.BTNmake.Size = new System.Drawing.Size(408, 165);
            this.BTNmake.TabIndex = 0;
            this.BTNmake.Text = "make somethimg happen";
            this.BTNmake.UseVisualStyleBackColor = true;
            this.BTNmake.Click += new System.EventHandler(this.BTNmake_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 311);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter an integer";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TBintCheck
            // 
            this.TBintCheck.Location = new System.Drawing.Point(395, 304);
            this.TBintCheck.Name = "TBintCheck";
            this.TBintCheck.Size = new System.Drawing.Size(100, 38);
            this.TBintCheck.TabIndex = 2;
            // 
            // BTNcheckInt
            // 
            this.BTNcheckInt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BTNcheckInt.ForeColor = System.Drawing.Color.Cyan;
            this.BTNcheckInt.Location = new System.Drawing.Point(642, 318);
            this.BTNcheckInt.Name = "BTNcheckInt";
            this.BTNcheckInt.Size = new System.Drawing.Size(157, 88);
            this.BTNcheckInt.TabIndex = 3;
            this.BTNcheckInt.Text = "Check integer";
            this.BTNcheckInt.UseVisualStyleBackColor = false;
            this.BTNcheckInt.Click += new System.EventHandler(this.BTNcheckInt_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(921, 88);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(70, 32);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "UAT";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1240, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 32);
            this.label2.TabIndex = 5;
            this.label2.Tag = "";
            this.label2.Text = "Skills - check all that apply";
            // 
            // CBDB
            // 
            this.CBDB.AutoSize = true;
            this.CBDB.Location = new System.Drawing.Point(1266, 136);
            this.CBDB.Name = "CBDB";
            this.CBDB.Size = new System.Drawing.Size(174, 36);
            this.CBDB.TabIndex = 6;
            this.CBDB.Text = "Database";
            this.CBDB.UseVisualStyleBackColor = true;
            this.CBDB.CheckedChanged += new System.EventHandler(this.CBDB_CheckedChanged);
            // 
            // CBNW
            // 
            this.CBNW.AutoSize = true;
            this.CBNW.Location = new System.Drawing.Point(1279, 178);
            this.CBNW.Name = "CBNW";
            this.CBNW.Size = new System.Drawing.Size(194, 36);
            this.CBNW.TabIndex = 7;
            this.CBNW.Text = "Networking";
            this.CBNW.UseVisualStyleBackColor = true;
            this.CBNW.CheckedChanged += new System.EventHandler(this.CBNW_CheckedChanged);
            // 
            // CBGUI
            // 
            this.CBGUI.AutoSize = true;
            this.CBGUI.Location = new System.Drawing.Point(1279, 229);
            this.CBGUI.Name = "CBGUI";
            this.CBGUI.Size = new System.Drawing.Size(101, 36);
            this.CBGUI.TabIndex = 8;
            this.CBGUI.Text = "GUI";
            this.CBGUI.UseVisualStyleBackColor = true;
            this.CBGUI.CheckedChanged += new System.EventHandler(this.CBGUI_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RBBSFalse);
            this.groupBox1.Controls.Add(this.RBBSTrue);
            this.groupBox1.Location = new System.Drawing.Point(729, 500);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(502, 310);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Have you graduated w a BS degree?";
            // 
            // RBBSTrue
            // 
            this.RBBSTrue.AutoSize = true;
            this.RBBSTrue.Location = new System.Drawing.Point(36, 87);
            this.RBBSTrue.Name = "RBBSTrue";
            this.RBBSTrue.Size = new System.Drawing.Size(100, 36);
            this.RBBSTrue.TabIndex = 0;
            this.RBBSTrue.TabStop = true;
            this.RBBSTrue.Text = "Yes";
            this.RBBSTrue.UseVisualStyleBackColor = true;
            this.RBBSTrue.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // RBBSFalse
            // 
            this.RBBSFalse.AutoSize = true;
            this.RBBSFalse.Location = new System.Drawing.Point(47, 156);
            this.RBBSFalse.Name = "RBBSFalse";
            this.RBBSFalse.Size = new System.Drawing.Size(87, 36);
            this.RBBSFalse.TabIndex = 1;
            this.RBBSFalse.TabStop = true;
            this.RBBSFalse.Text = "No";
            this.RBBSFalse.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BTNRadio);
            this.groupBox2.Controls.Add(this.RBSR);
            this.groupBox2.Controls.Add(this.RBJR);
            this.groupBox2.Controls.Add(this.RBSO);
            this.groupBox2.Controls.Add(this.RBFR);
            this.groupBox2.Location = new System.Drawing.Point(92, 477);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(631, 322);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "What class are you ?";
            // 
            // RBFR
            // 
            this.RBFR.AutoSize = true;
            this.RBFR.Location = new System.Drawing.Point(26, 59);
            this.RBFR.Name = "RBFR";
            this.RBFR.Size = new System.Drawing.Size(88, 36);
            this.RBFR.TabIndex = 0;
            this.RBFR.TabStop = true;
            this.RBFR.Text = "FR";
            this.RBFR.UseVisualStyleBackColor = true;
            // 
            // RBSO
            // 
            this.RBSO.AutoSize = true;
            this.RBSO.Location = new System.Drawing.Point(26, 122);
            this.RBSO.Name = "RBSO";
            this.RBSO.Size = new System.Drawing.Size(92, 36);
            this.RBSO.TabIndex = 1;
            this.RBSO.TabStop = true;
            this.RBSO.Text = "SO";
            this.RBSO.UseVisualStyleBackColor = true;
            // 
            // RBJR
            // 
            this.RBJR.AutoSize = true;
            this.RBJR.Location = new System.Drawing.Point(17, 190);
            this.RBJR.Name = "RBJR";
            this.RBJR.Size = new System.Drawing.Size(85, 36);
            this.RBJR.TabIndex = 2;
            this.RBJR.TabStop = true;
            this.RBJR.Text = "JR";
            this.RBJR.UseVisualStyleBackColor = true;
            // 
            // RBSR
            // 
            this.RBSR.AutoSize = true;
            this.RBSR.Location = new System.Drawing.Point(7, 250);
            this.RBSR.Name = "RBSR";
            this.RBSR.Size = new System.Drawing.Size(90, 36);
            this.RBSR.TabIndex = 3;
            this.RBSR.TabStop = true;
            this.RBSR.Text = "SR";
            this.RBSR.UseVisualStyleBackColor = true;
            // 
            // BTNRadio
            // 
            this.BTNRadio.Location = new System.Drawing.Point(174, 79);
            this.BTNRadio.Name = "BTNRadio";
            this.BTNRadio.Size = new System.Drawing.Size(504, 147);
            this.BTNRadio.TabIndex = 11;
            this.BTNRadio.Text = "BTNRadio";
            this.BTNRadio.UseVisualStyleBackColor = true;
            this.BTNRadio.Click += new System.EventHandler(this.BTNRadio_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1321, 420);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(529, 484);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // BTNRoll
            // 
            this.BTNRoll.Location = new System.Drawing.Point(1397, 288);
            this.BTNRoll.Name = "BTNRoll";
            this.BTNRoll.Size = new System.Drawing.Size(361, 97);
            this.BTNRoll.TabIndex = 12;
            this.BTNRoll.Text = "Roll Die";
            this.BTNRoll.UseVisualStyleBackColor = true;
            this.BTNRoll.Click += new System.EventHandler(this.BTNRoll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1855, 910);
            this.Controls.Add(this.BTNRoll);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CBGUI);
            this.Controls.Add(this.CBNW);
            this.Controls.Add(this.CBDB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.BTNcheckInt);
            this.Controls.Add(this.TBintCheck);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTNmake);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "GUI form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNmake;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBintCheck;
        private System.Windows.Forms.Button BTNcheckInt;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CBDB;
        private System.Windows.Forms.CheckBox CBNW;
        private System.Windows.Forms.CheckBox CBGUI;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RBBSFalse;
        private System.Windows.Forms.RadioButton RBBSTrue;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RBSR;
        private System.Windows.Forms.RadioButton RBJR;
        private System.Windows.Forms.RadioButton RBSO;
        private System.Windows.Forms.RadioButton RBFR;
        private System.Windows.Forms.Button BTNRadio;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNRoll;
    }
}

